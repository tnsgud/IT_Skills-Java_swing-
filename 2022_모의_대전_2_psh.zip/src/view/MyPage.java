package view;

import tool.Tool;

public class MyPage extends BaseFrame implements Tool {

}

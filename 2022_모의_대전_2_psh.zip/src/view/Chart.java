package view;

public class Chart extends BaseFrame {

}

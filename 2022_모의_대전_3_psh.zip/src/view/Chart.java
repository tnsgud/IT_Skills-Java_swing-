package view;

public class Chart extends BaseFrame {
	public Chart() {
		super("차트", 100, 100);
		
		setVisible(true);
	}
}

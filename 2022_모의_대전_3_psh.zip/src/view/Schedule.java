package view;

public class Schedule extends BaseFrame {
	public Schedule() {
		super("월별 일정", 100, 100);
		
		setVisible(true);
	}
}

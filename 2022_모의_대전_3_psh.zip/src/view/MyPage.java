package view;

public class MyPage extends BaseFrame {
	public MyPage() {
		super("마이페이지", 100, 100);
		
		setVisible(true);
	}
}
